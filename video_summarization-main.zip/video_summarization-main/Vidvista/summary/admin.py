from django.contrib import admin
from .models import FeedBack

# Register your models here.
admin.site.register(FeedBack)